A2 CDA File Generator v1.8 by tha_proxinator
--------------------------------------------------------------------------

QUOTE:

	Hi
	
	This is my first program i have made which generates a "customize_upgrade.xml"
	that will change your CDA to upload to your A2 DB3150/DB3210/DB2020/PNX5230 phone.
	Oh and I tested every function by myself.
	
	Hope you like it!

New features:
*make update CDA list feature more stable
*make update feature work
*have update.ini and able to put url where cda lists are
*auto create update.ini if doesn't exist
*collect many cda's and and them to cda lists
*Change gui to look better e.g. font
*add Other platforms - done (db2020 and pnx5230)
*removed k700 (i had no idea why it was there in the first place(not a2))
*add editing of cda lists within the program
*add right-click "Edit List" to open CDA List in notepad
*add right-click "Update List" to edit updae.ini in notepad
*reject all errors without program failing to function properly
*ensure cda lists can be updated correctly
*add left-click(hold) "Generate XML File" and press "Shift" to save file elsewhere
*new icon
*make pictures transparent
*add M-EAST-N-AFR generic cda for all db3210 models

--------------------------------------------------------------------------

SUPPORTED A2 PHONES:

C510 *NEW*
C702
C901 *NEW*
C902
C903 *NEW*
C905
G502
G705
K630
K660
K700
K850
T700
T707 *NEW*
V640
W508 *NEW*
W595
W705
W715 *NEW*
W760
W890
W902
W910
W980
W995 *NEW*
Z750
Z770
Z780
Other (db2020/pnx5230) *NEW*

--------------------------------------------------------------------------

How to generate the file:

1. Open "A2 CDA File Generator.exe" and select your model.

2. Select a Region/Language.

3. You have three options;
 a ) Select a Region/Language and it will generate a default Generic CDA.
 b ) Leave the Region/Language blank and enter a CDA.
 c ) Click ">" on the right-hand side and select a CDA from the CDA List.

4. Enter your CDA Revision if not provided. (optional)

5. To save "customize_upgrade.xml",either,
 a ) Click "Generate XML File".
 b ) Left-click(hold) "Generate XML File" and press "Shift" to save
the file elsewhere.

--------------------------------------------------------------------------

~~DB3150/DB3210~~
UPLOADING "customize_upgrade.xml" TO YOUR PHONE:

What you Need:
- A2 Uploader
- Gordan Gate's SE flash drivers

6. Install Gordan Gate's SE flash drivers (ggsetup.exe).

7. Open A2Uploader.

8. Click "FileSystem Tool". Connect phone via usb holding '2+5' or 'C'.
you can let go of '2+5' or 'C' once A2Uploader has detected your phone.

9. Browse to the directory 'tpa/preset/custom' then copy over
"customize_upgrade.xml".

10. Click "Shutdown FS Manager". Disconnect your phone and turn it on.

11. You will be prompted "Please Wait". This is when the CDA is changed.

12. When the prompt "Please Wait" has gone, turn off the phone.

~~DB2020/PNX5230~~
UPLOADING "customize_upgrade.xml" TO YOUR PHONE:

What you Need:
- XS++
- Gordan Gate's SE flash drivers

6. Install Gordan Gate's SE flash drivers (ggsetup.exe).

7. Open XS++.

8. Click "Connect". Connect phone via usb holding '2+5' or 'C'.
you can let go of '2+5' or 'C' once A2Uploader has detected your phone.

9. Select "FSX", then click "Start FSX". Browse to the directory
'tpa/preset/custom' then copy over "customize_upgrade.xml".

10. Click "Shutdown". Disconnect your phone and turn it on.

11. You will be prompted "Please Wait". This is when the CDA is changed.

12. When the prompt "Please Wait" has gone, turn off the phone.

--------------------------------------------------------------------------

DEBRANDING YOUR PHONE:

What you Need:
- SEUS (Sony Ericsson Update Service)
- Gordan Gate's SE flash drivers

13. Install SEUS. Run SEUS and follow the prompts.

Enjoy a debranded phone!

--------------------------------------------------------------------------

**CDA LIST EDITING AND UPDATING**

Editing:

1. To edit lists, either:
 a ) Click "Edit List". This will open the list in the program so you can edit it.
 b ) Right-click "Edit List" to edit in the default application for editing ".txt"
2. When done editing, save it.

Updating:

1. To update lists, either:
 a ) Click "Update List". This will update the list given the url in "update.ini"
 b ) Right-click "Update List" to edit the url where the cda list are located.
2. The Program will warn you if a current CDA list exists.
3. "List updated!" will show at the bottom left of the program if the update was successful.

--------------------------------------------------------------------------