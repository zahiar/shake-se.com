Rotating Logo Creator by kr8ter

This program will help you create your own rotating logos.

In order to run the program, you need the following:
*  Latest version of JAVA installed
*  Adobe Flash CS4 installed in it's default directory (C:\Program Files\Adobe\Adobe Flash CS4)

You MUST NOT change the action-script, as this will break the rotating logo, and the logo will not rotate!

Also, you cannot export the rotating logo using Adobe Flash, as the picture will be missing, therefore use the program to create the logo for you. The swf file should be called "Rotating Logo by kr8ter".