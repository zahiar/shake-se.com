Custom Menu Creator by kr8ter

This program will help you create your own menus with/without pass protection.

In order to run the program, you need the following:
*  Latest version of JAVA installed
*  Adobe Flash CS4 installed in it's default directory (C:\Program Files\Adobe\Adobe Flash CS4)

The SourceCode.fla file can be edited and you may change the icons, background, etc.

You MUST NOT change the actionscript or any variable names, as this will break the menu, and the menu WILL NOT work!

Also, you cannot export the menu using Adobe Flash, as some of the actionscript is missing, therefore use the program to create the menu for you.