Simply Aino Flash Menu By kr8ter

To access the locked features, first open up the menu and then goto the locked icon and press Select. Now type in the keycode.

If you make a mistake, simply press the # key and then key in the passcode

The passcode is 2580