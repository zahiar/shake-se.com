Place the files in the following directories:

Splatta_desktop.swf: tpa / preset / system / desktop / flash 
Albumart_SplattaWalkman.swf: tpa / preset / system / walkman 

Splatta-aino.thm: place it on the phone/memory card in themes folder