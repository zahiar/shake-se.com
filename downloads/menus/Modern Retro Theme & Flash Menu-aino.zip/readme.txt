Modern Retro Theme & Flash Menu by kr8ter

The menu is locked, and will not display any icons until you unlock it.

To unlock the menu, press the following keys in the given order:
Up, Down, Left, Right