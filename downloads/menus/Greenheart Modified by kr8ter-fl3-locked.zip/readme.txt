Greenheart by Dahliana, modified by kr8ter

The menu is locked and requires a password to unlock it.

The password is 0000