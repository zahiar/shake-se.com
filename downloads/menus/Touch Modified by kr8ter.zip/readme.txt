Touch Menu Modified by kr8ter

To access the locked features, first open up the menu and then goto the locked icon and press Select. The icon will be yellow, and now type in the keycode.

If you make a mistake, simply press the # key and then key in the passcode

The passcode is 1234