Faulty Carbon Flash Menu By kr8ter

To access the locked features, first open up the menu and then type in the keycode.

The passcode is 2580